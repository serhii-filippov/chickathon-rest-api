//
//  Bot.hpp
//  CPPBot
//
//  Created by Andrew Danileyko on 1/15/19.
//  Copyright © 2019 Andrew Danileyko. All rights reserved.
//

#ifndef Bot_hpp
#define Bot_hpp

#include <stdio.h>
#include "BotInterface.h"

class Bot : public BotInterface {
public:
    void turn(Client *client, int turnNumber) override;

    Bot() {
        
    }
    
    ~Bot() {
        
    }
};

#endif /* Bot_hpp */
