//
//  BotInterface.hpp
//  CPPBot
//
//  Created by Andrew Danileyko on 1/15/19.
//  Copyright © 2019 Andrew Danileyko. All rights reserved.
//

#ifndef BotInterface_hpp
#define BotInterface_hpp

#include <stdio.h>
class Client;

class BotInterface {
public:
    void virtual turn(Client *client, int turnNumber) = 0;
};

#endif /* BotInterface_hpp */
