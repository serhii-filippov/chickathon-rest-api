//
//  Utils.hpp
//  CPPBot
//
//  Created by Andrew Danileyko on 1/17/19.
//  Copyright © 2019 Andrew Danileyko. All rights reserved.
//

#ifndef Utils_hpp
#define Utils_hpp

#include <stdio.h>
#include <string>

using namespace std;

class Utils {
public:
    static vector<string>* componetsSepratedBy(string &s, string delim) {
        vector<string> *result = new vector<string>;
        
        size_t pos = 0;
        string token;
        while ((pos = s.find(delim)) != string::npos) {
            token = s.substr(0, pos);
            result->push_back(token);
            s.erase(0, pos + delim.length());
        }
        if (s.empty() == false) {
            result->push_back(s);
        }
        
        return result;
    }
};

#endif /* Utils_hpp */
