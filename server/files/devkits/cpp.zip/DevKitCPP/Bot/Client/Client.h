//
//  Client.hpp
//  CPPBot
//
//  Created by Andrew Danileyko on 1/15/19.
//  Copyright © 2019 Andrew Danileyko. All rights reserved.
//

#ifndef Client_hpp
#define Client_hpp

#include <stdio.h>
#include <vector>
#include <thread>
#include "BotInterface.h"
#include "MapObject.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <cmath>
#include "Utils.h"

using namespace std;

class Client {
public:
    
    vector<MapObject *> allPlanets;
    vector<MapObject *> myPlanets;
    vector<MapObject *> enemyPlanets;
    vector<MapObject *> neutralPlanets;
    vector<MapObject *> notMyPlanets;
    vector<MapObject *> allShips;
    vector<MapObject *> myShips;
    vector<MapObject *> enemyShips;
    int turnNumber;
    bool shouldStop;
    int _sockfd; // socket file descriptor

    Client(BotInterface &bot, int port) : _bot(bot) {
        _port = port;
        turnNumber = 0;
        _shipsSpeed = 0.04; // default value
        shouldStop = false;
        connectToServer();
        thread _thread(&Client::run, this);
        _thread.detach();
    }
    
    void turn() {
        _bot.turn(this, turnNumber);
    }
    
    void endTurn() {
        sendString("#endTurn");
    }
    
    void sendString(const string &str) {
        size_t wbytes;

        size_t len = str.length();
        char buffer[2];
        buffer[0] = (0xff & (len >> 8));
        buffer[1] = (0xff & len);

        string _outString = str;
        _outString.insert(0, buffer, 2);
        
        char *wbuff = (char *)_outString.c_str();
        size_t size = strlen(str.c_str()) + 2;
        wbytes = send(_sockfd, wbuff, size, 0);
    }
    
    void sendFromTo(MapObject *from, MapObject *to, int count) {
        string _string = "#send:"+to_string(from->id)+","+to_string(to->id)+","+to_string(count);
        sendString(_string);
        from->value -= count;
    }
    
    double distance(MapObject *from, MapObject *to) {
        double x = to->x - from->x;
        double y = to->y - from->y;
        double distance = sqrt(x*x + y*y);
        return distance;
    }
    
    int turns(MapObject *from, MapObject *to) {
        double dist = distance(from, to);
        double turns = dist / _shipsSpeed;
        int intTurns = (int)turns;
        if (turns > intTurns) {
            intTurns++;
        }
        return intTurns;
    }
    
    double shipsSpeed() {
        return _shipsSpeed;
    }
    
    void connectToServer() {
        bool connected = false;

        while (connected == false) {
            this_thread::sleep_for(chrono::milliseconds(100));
            struct sockaddr_in serv_addr;
            struct hostent *server;
            
            _sockfd = socket(AF_INET, SOCK_STREAM, 0); // generate file descriptor
            if (_sockfd < 0) {
                perror("ERROR opening socket");
                continue;
            }
            
            server = gethostbyname("localhost"); //the ip address (or server name) of the listening server.
            if (server == NULL) {
                fprintf(stderr,"ERROR, no such host\n");
                continue;
            }
            
            bzero((char *) &serv_addr, sizeof(serv_addr));
            serv_addr.sin_family = AF_INET;
            bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
            serv_addr.sin_port = htons(_port);
            
            if (connect(_sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0) {
                perror("ERROR connecting");
                continue;
            }
            connected = true;
        }
    }
    
    void run() {
        char *rbuff = (char *)malloc(50000);
        ssize_t rbytes;
        while (shouldStop == false) {
            rbytes = recv(_sockfd, rbuff, 50000, 0); // similar to read(), but return -1 if socket closed
            rbuff[rbytes] = '\0'; // set null terminal
            if (rbytes == -1) {
                shouldStop = true;
            } else {
                if (rbytes > 2) {
                    string _string(rbuff + 2, rbuff + rbytes);
                    int stopResult = _string.compare("stop");
                    if (stopResult == 0) {
                        stop();
                    } else {
                        vector<string> *components = Utils::componetsSepratedBy(_string, ":");
                        if (components->size() == 3) {
                            parseObjects((*components)[0]);
                            parseObjects((*components)[1]);
                            parseMeta((*components)[2]);
                            turn();
                        } else {
                            endTurn();
                        }
                        delete components;
                    }
                }
            }
        }
        free(rbuff);
    }
    
    void parseObjects(string &_string) {
        vector<string> *arr = Utils::componetsSepratedBy(_string, "#");
        vector<MapObject *> list;
        
        if (arr->size() > 1) {
            vector<string> *ps = Utils::componetsSepratedBy((* arr)[1], ";");
            for (int i = 0; i < ps->size(); i++) {
                string objectString = (*ps)[i];
                MapObject *object = NULL;
                if (objectString.empty() == false) {
                    object = new MapObject(objectString);
                }
                object->id = i;
                if (object != NULL) {
                    list.push_back(object);
                }
            }
            
            delete ps;
        }
        
        if ((*arr)[0].compare("planets") == 0) {
            clearVector(allPlanets);
            myPlanets.clear();
            notMyPlanets.clear();
            enemyPlanets.clear();
            neutralPlanets.clear();
            for (vector<MapObject *>::iterator it = list.begin(); it != list.end(); ++it) {
                MapObject *object = *it;
                allPlanets.push_back(object);
                switch (object->own) {
                    case 0: {
                        neutralPlanets.push_back(object);
                        notMyPlanets.push_back(object);
                    } break;
                        
                    case 1: {
                        myPlanets.push_back(object);
                    } break;
                        
                    case 2: {
                        enemyPlanets.push_back(object);
                        notMyPlanets.push_back(object);
                    } break;
                }
            }
        }
        
        if ((*arr)[0].compare("ships") == 0) {
            clearVector(allShips);
            myShips.clear();
            enemyShips.clear();
            for (vector<MapObject *>::iterator it = list.begin(); it != list.end(); ++it) {
                MapObject *object = *it;
                allShips.push_back(object);
                switch (object->own) {
                    case 1: {
                        myShips.push_back(object);
                    } break;
                        
                    case 2: {
                        enemyShips.push_back(object);
                    } break;
                }
            }
        }
        
        list.clear();
        delete arr;
    }
    
    void parseMeta(string &_string) {
        vector<string> *arr = Utils::componetsSepratedBy(_string, "#");
        if (arr->size() > 1) {
            vector<string> *ps = Utils::componetsSepratedBy((*arr)[1], ";");
            _shipsSpeed = stod((*ps)[0]);
            turnNumber = stoi((*ps)[1]);
        }
        
        delete arr;
    }
    
    void stop() {
        shouldStop = true;
    }
    
    template<typename VectorType>
    void clearVector(vector<VectorType> &vec) {
        for (typename vector<VectorType>::iterator object = vec.begin(); object != vec.end(); ++object) {
            delete *object; // Note that this is deleting what pObj points to,
        }
        
        vec.clear();
    }
    
    ~Client() {
        
    }
    
private:
    int _port;
    BotInterface &_bot;
    double _shipsSpeed;
};

#endif /* Client_hpp */
