//
//  MapObject.hpp
//  CPPBot
//
//  Created by Andrew Danileyko on 1/15/19.
//  Copyright © 2019 Andrew Danileyko. All rights reserved.
//

#ifndef MapObject_hpp
#define MapObject_hpp

#include <stdio.h>
#include "Utils.h"

using namespace std;

class MapObject {
public:
    double x;
    double y;
    int type;
    int size;
    int value;
    int own;
    int numberOfTurns;
    int id;
    int fromId;
    int toId;
    
    MapObject(string &str) {
        vector<string> *arr = Utils::componetsSepratedBy(str, ",");
        type = stoi((*arr)[0]);
        x = stod((*arr)[1]);
        y = stod((*arr)[2]);
        value = stoi((*arr)[3]);
        own = stoi((*arr)[4]);
        if (type == 1) {
            size = stoi((*arr)[5]);
            fromId = 0;
            toId = 0;
            numberOfTurns = 0;
        } else {
            size = 0;
            id = 0;
            fromId = stoi((*arr)[5]);
            toId = stoi((*arr)[6]);
            numberOfTurns = stoi((*arr)[7]);
        }
    }
    
    ~MapObject() {
    }
};

#endif /* MapObject_hpp */
