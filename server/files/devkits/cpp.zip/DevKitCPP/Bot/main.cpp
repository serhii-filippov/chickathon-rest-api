//
//  main.cpp
//  CPPBot
//
//  Created by Andrew Danileyko on 1/15/19.
//  Copyright © 2019 Andrew Danileyko. All rights reserved.
//

#include <iostream>
#include <string>
#include <thread>
#include <chrono>

#include "Bot.h"
#include "Client.h"

using namespace std;

int main(int argc, const char * argv[]) {
    string port = "15000";
    if (argc == 3) {
        port = argv[2];
    }
    
    Bot bot;
    Client client(bot, stoi(port));
    while (client.shouldStop == false) {
        this_thread::sleep_for(chrono::milliseconds(100));
    }
    
    return 0;
}
