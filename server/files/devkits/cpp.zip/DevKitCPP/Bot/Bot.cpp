//
//  Bot.cpp
//  CPPBot
//
//  Created by Andrew Danileyko on 1/15/19.
//  Copyright © 2019 Andrew Danileyko. All rights reserved.
//

#include "Bot.h"
#include "Client.h"

void Bot::turn(Client *client, int turnNumber) {
    if (client->notMyPlanets.size() > 0) {
        MapObject *toPlanet = client->notMyPlanets[0];
        for (vector<MapObject *>::iterator it = client->myPlanets.begin(); it != client->myPlanets.end(); ++it) {
            MapObject *planet = *it;
            if (planet->value > 1) {
                client->sendFromTo(planet, toPlanet, 1);
            }
        }
    }
    client->endTurn();
}
