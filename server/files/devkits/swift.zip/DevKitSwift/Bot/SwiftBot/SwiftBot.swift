//
//  SwiftBot.swift
//  SwiftBot
//
//  Created by Andrew on 26.01.2019.
//  Copyright © 2019 AndrewDanileyko. All rights reserved.
//

import Foundation

class SwiftBot : BotInterface {
    func turn(client: Client, turnNumber: Int) {
        // Логику бота писать тут
        if (turnNumber % 2 == 0) {
            if (client.enemyPlanets.count > 0) {
                let enemyPlanet = client.enemyPlanets.first!;
                for myPlanet in client.myPlanets {
                    let shipsToSend = myPlanet.value
                    client.send(from: myPlanet, to: enemyPlanet, count: shipsToSend)
                }
            }
        }
        
        client.endTurn()
    }
}
