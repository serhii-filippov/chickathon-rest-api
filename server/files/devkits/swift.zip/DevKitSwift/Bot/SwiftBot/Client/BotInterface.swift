//
//  BotInterface.swift
//  SwiftBot
//
//  Created by Andrew on 26.01.2019.
//  Copyright © 2019 AndrewDanileyko. All rights reserved.
//

import Cocoa

protocol BotInterface {
    func turn(client: Client, turnNumber: Int);
}
