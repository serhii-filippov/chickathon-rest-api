//
//  Client.swift
//  SwiftBot
//
//  Created by Andrew on 26.01.2019.
//  Copyright © 2019 AndrewDanileyko. All rights reserved.
//

import Cocoa

class Client : NSObject, StreamDelegate {

    let bot : BotInterface
    let port : NSInteger
    var turnNumber : NSInteger = 0
    var shipsSpeed : Double = 0.04
    var inputStream : InputStream? = nil
    var outputStream : OutputStream?  = nil
    public var shouldStop : Bool
    var thread : Thread?
    
    var allPlanets : Array<MapObject>
    var myPlanets : Array<MapObject>
    var enemyPlanets : Array<MapObject>
    var neutralPlanets : Array<MapObject>
    var notMyPlanets : Array<MapObject>
    var allShips : Array<MapObject>
    var myShips : Array<MapObject>
    var enemyShips : Array<MapObject>
    var buffer = [UInt8](repeating: 0, count: 50000)

    init(bot: BotInterface, port: String) {
        self.bot = bot;
        self.port = NSInteger(port)!
        self.shouldStop = false
        self.allPlanets = Array()
        self.myPlanets = Array()
        self.enemyPlanets = Array()
        self.neutralPlanets = Array()
        self.notMyPlanets = Array()
        self.allShips = Array()
        self.myShips = Array()
        self.enemyShips = Array()

        super.init()
        self.thread = Thread.init(target: self, selector: #selector(run), object: nil)
        self.thread?.start()
    }
    
    @objc public func run() {
//        var connected = false
        
        var readStream : Unmanaged<CFReadStream>?
        var writeStream : Unmanaged<CFWriteStream>?
        
        CFStreamCreatePairWithSocketToHost(kCFAllocatorDefault, "localhost" as CFString, UInt32(self.port), &readStream, &writeStream)
        
        self.inputStream = readStream!.takeRetainedValue()
        self.outputStream = writeStream!.takeRetainedValue()        
        self.inputStream!.delegate = self
        self.outputStream!.delegate = self
        
        self.inputStream!.schedule(in: RunLoop.current, forMode: RunLoop.Mode.default)
        self.outputStream!.schedule(in: RunLoop.current, forMode: RunLoop.Mode.default)
        
        self.inputStream!.open()
        self.outputStream!.open()
    
        var status : Stream.Status
        repeat {
            status = self.inputStream!.streamStatus;
            usleep(10000)
        } while (status == .opening)
        
        if (status == .error) {
            self.shouldStop = true;
        } else {
            RunLoop.current.run()
        }
    }
    
    func stream(_ aStream: Stream, handle eventCode: Stream.Event) {
        switch eventCode {
        case Stream.Event.errorOccurred: 
            print("ERROR")
            
        case Stream.Event.endEncountered: 
            aStream.close()
            aStream.remove(from: RunLoop.current, forMode: RunLoop.Mode.default)
            
        case Stream.Event.hasBytesAvailable where aStream == inputStream: 
            while (self.inputStream!.hasBytesAvailable){
                let len = self.inputStream!.read(&buffer, maxLength: buffer.count)
                
                if (len > 0) {
                    let subBuffer = self.buffer[2..<len];
                    let string = String.init(bytes: subBuffer, encoding: String.Encoding.utf8)
                    if (string == "stop") {
                        self.stop()
                    } else {
                        let components = string!.components(separatedBy: ":")
                        if (components.count == 3) {
                            self.parseObjects(string: components[0])
                            self.parseObjects(string: components[1])
                            self.parseMeta(string: components[2])
                            self.turn()
                        } else {
                            self.endTurn()
                        }
                    }
                }
            }
            
        case Stream.Event.hasSpaceAvailable where aStream == outputStream:
            break
            
        default:
            break
        }
    }
    
    func stop() {
        self.inputStream!.close()
        self.inputStream!.remove(from: RunLoop.current, forMode: RunLoop.Mode.default)
        self.outputStream!.close()
        self.outputStream!.remove(from: RunLoop.current, forMode: RunLoop.Mode.default)
        
//        CFRunLoopStop(CFRunLoopGetCurrent());
        self.shouldStop = true;
    }
    
    func parseObjects(string : String) {
        let arr : Array<String> = string.components(separatedBy: "#")
        var list : Array<MapObject> = Array()
        
        if (arr.count > 1) {
            let ps = arr[1].components(separatedBy: ";")
            for i in 0 ... ps.count-1 {
                let objectString : String? = ps[i]
                var object : MapObject? = nil;
                if (objectString! != "") {
                    object = MapObject.init(string: objectString!)
                }
                if (object != nil) {
                    object!.id = i;
                    list.append(object!)
                }
            }
        }
        
        if (arr[0] == "planets") {
            self.allPlanets.removeAll()
            self.myPlanets.removeAll()
            self.notMyPlanets.removeAll()
            self.enemyPlanets.removeAll()
            self.neutralPlanets.removeAll()
            for object in list {
                self.allPlanets.append(object)
                switch object.own {
                case 0:
                    self.neutralPlanets.append(object)
                    self.notMyPlanets.append(object)
                    
                case 1:
                    self.myPlanets.append(object)

                case 2:
                    self.enemyPlanets.append(object)
                    self.notMyPlanets.append(object)
                default:
                    break
                }
            }
        }

        if (arr[0] == "ships") {
            self.allShips.removeAll()
            self.myShips.removeAll()
            self.enemyShips.removeAll()
            for object in list {
                self.allShips.append(object)
                switch (object.own) {
                case 1:
                    self.myShips.append(object)

                case 2:
                    self.enemyShips.append(object)
                    
                default:
                    break
                }
            }
        }
    }

    func parseMeta(string : String) {
        let arr = string.components(separatedBy:"#")
        if (arr.count > 1) {
            let ps = arr[1].components(separatedBy: ";")
            self.shipsSpeed = Double(ps[0])!
            self.turnNumber = Int(ps[1])!
        }
    }

    func turn() {
        self.bot.turn(client: self, turnNumber: self.turnNumber)
    }

    func endTurn() {
        self.send(string: "#endTurn")
    }
    
    private func send(string : String) {
        if self.outputStream!.hasSpaceAvailable {
            let data = self.convertToJavaUTF8(string: string)
            self.outputStream!.write(data, maxLength: data.count)
        }
    }

    func send(from: MapObject, to: MapObject, count: Int) {
        let string = String.init(format: "#send:%d,%d,%d", from.id, to.id, count)
        self.send(string: string)
        from.value -= count;
    }
    
    func convertToJavaUTF8(string: String) -> [UInt8] {
        let len = string.lengthOfBytes(using: .utf8)
        var buffer = [UInt8](repeating: 0, count: 2)
        buffer[0] = (UInt8)(0xff & (len >> 8));
        buffer[1] = (UInt8)(0xff & len);
        let outData = buffer + [UInt8](string.utf8)
        return outData;
    }
    
    func distance(from: MapObject, to: MapObject) -> Double {
        let x = to.x - from.x;
        let y = to.y - from.y;
        let distance = sqrt(x*x + y*y);
        return distance;
    }
    
    func turns(from: MapObject, to: MapObject) -> Int {
        let distance = self.distance(from:from, to:to)
        let turns = distance / self.shipsSpeed;
        var intTurns = (Double)((Int)(turns));
        if turns > intTurns {
            intTurns = intTurns + 1;
        }
        return (Int)(intTurns);
    }
    
}
