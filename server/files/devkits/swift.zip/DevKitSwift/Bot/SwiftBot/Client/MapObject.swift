//
//  MapObject.swift
//  SwiftBot
//
//  Created by Andrew Danileyko on 1/28/19.
//  Copyright © 2019 AndrewDanileyko. All rights reserved.
//

import Cocoa

class MapObject: NSObject {
    var x : Double
    var y : Double
    var type : Int
    var size : Int
    var value : Int
    var own : Int
    var numberOfTurns : Int
    var id : Int
    var fromId : Int
    var toId : Int
    
    init(string: String) {
        let arr = string.components(separatedBy: ",")
        self.type = Int(arr[0])!
        self.x = Double(arr[1])!
        self.y = Double(arr[2])!
        self.value = Int(arr[3])!
        self.own = Int(arr[4])!
        self.id = 0;
        if (self.type == 1) {
            self.size = Int(arr[5])!
            self.fromId = 0;
            self.toId = 0;
            self.numberOfTurns = 0;
        } else {
            self.size = 0;
            self.fromId = Int(arr[5])!
            self.toId = Int(arr[6])!
            self.numberOfTurns = Int(arr[7])!
        }
        super.init()
    }
}
