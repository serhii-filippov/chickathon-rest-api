//
//  main.swift
//  SwiftBot
//
//  Created by Andrew on 26.01.2019.
//  Copyright © 2019 AndrewDanileyko. All rights reserved.
//

import Foundation

var port = "15000"

NSLog("args %@", CommandLine.arguments)

for i in 0 ... CommandLine.arguments.count - 1 {
    let argument = CommandLine.arguments[i]
    if (argument == "-p") {
        port = CommandLine.arguments[i + 1]
    }
}

let bot = SwiftBot()
let client = Client(bot: bot, port: port)
while (client.shouldStop == false) {
    usleep(10000)
}

NSLog("[Swift Bot]: Finished")

