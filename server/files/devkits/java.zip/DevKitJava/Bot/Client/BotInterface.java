public interface BotInterface {
    public void turn(Client client, int turnNumber);
}
