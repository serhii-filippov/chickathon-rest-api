import sys
from client.client import Client


class SequenceBot:
    @staticmethod
    def turn(client, turn_number):
        if len(client.not_my_planets) > 0:
            to_planet = client.not_my_planets[0]
            for planet in client.my_planets:
                if planet.value > 1:
                    client.send(planet, to_planet, 1)
        client.end_turn()


# bot.py -h localhost -p 15000
def main(args):
    ip_address, port = args[1], args[3]
    cl = Client(bot=SequenceBot, ip_address=ip_address, port=port)
    cl.run()


if __name__ == "__main__":
    main(sys.argv[1:])
