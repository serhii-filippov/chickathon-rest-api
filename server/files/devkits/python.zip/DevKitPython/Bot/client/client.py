import math
import time
import socket
from client.map_object import MapObject


class Client:
    # planets
    all_planets = []
    neutral_planets = []
    not_my_planets = []
    my_planets = []
    enemy_planets = []
    # ships
    all_ships = []
    my_ships = []
    enemy_ships = []
    # socket methods
    _in = None
    _out = None

    def __init__(self, bot, ip_address, port):
        self._bot = bot
        self.port = int(port)
        self.turn_number = 0
        self._ships_speed = 0.04  # default value
        self.should_stop = False
        self.ip_address = ip_address

    def run(self):
        connection = False
        while not connection:
            try:
                print(f"connecting: {self.ip_address} p: {self.port}")
                conn = socket.socket()
                conn.connect((self.ip_address, self.port))
                self._in = conn.recv
                self._out = conn.sendall
                connection = True
                print('connected')
            except Exception as e:
                print(e)
                time.sleep(1)

        if connection:
            sr = StreamReader(self._in, self)
            sr.run()
            conn.close()

    def parse_meta(self, s):
        arr = s.split("#")
        if len(arr) > 1:
            ps = arr[1].split(";")
            self._ships_speed = float(ps[0])
            self.turn_number = int(ps[1])

    def parse_objects(self, s):
        arr = s.split('#')
        map_object_list = []
        if len(arr) > 1:
            if arr[1]:
                ps = arr[1].split(';')
                for n, x in enumerate(ps):
                    x = x.split(",")
                    obj = MapObject(x)
                    obj.id = n
                    map_object_list.append(obj)

        if arr[0] == 'planets':
            self.all_planets.clear()
            self.my_planets.clear()
            self.not_my_planets.clear()
            self.enemy_planets.clear()
            self.neutral_planets.clear()
            for x in map_object_list:
                self.all_planets.append(x)
                if x.own == 0:
                    self.neutral_planets.append(x)
                    self.not_my_planets.append(x)
                elif x.own == 1:
                    self.my_planets.append(x)
                elif x.own == 2:
                    self.enemy_planets.append(x)
                    self.not_my_planets.append(x)
        elif arr[0] == 'ships':
            self.all_ships.clear()
            self.enemy_ships.clear()
            self.my_ships.clear()
            for x in map_object_list:
                self.all_ships.append(x)
                if x.own == 1:
                    self.my_ships.append(x)
                elif x.own == 2:
                    self.enemy_ships.append(x)

    @staticmethod
    def add_buffer(s):
        s_len = len(s)
        buffer = bytes([0xff & (s_len >> 8), (0xff & s_len)]) + bytes(s, 'utf-8')
        return buffer

    # game methods
    def turn(self):
        self._bot.turn(self, self.turn_number)

    def end_turn(self):
        self._out(self.add_buffer('#endTurn'))

    def send(self, from_obj, to_obj, count):
        self._out(self.add_buffer(f"#send:{from_obj.id},{to_obj.id},{count}"))
        from_obj.value -= count

    # get distance between objects
    @staticmethod
    def distance(from_obj, to_obj):
        x = to_obj.x - from_obj.x
        y = to_obj.y - from_obj.y
        return math.sqrt(pow(x, 2) + pow(y, 2))

    @property
    def ships_speed(self):
        return self._ships_speed

    def turns_from_to(self, from_obj, to_obj):
        distance = self.distance(from_obj, to_obj)
        turns = distance / self.ships_speed
        int_turns = int(turns)
        if turns > int_turns:
            int_turns += 1
        return int_turns

    def stop(self):
        self.should_stop = True


class StreamReader:

    def __init__(self, s_read, client):
        self.read = s_read
        self._client = client

    def run(self):
        # Read message from socket
        line = self.read(1638400)
        while line and not self._client.should_stop:
            # cut header of message with 2 bytes, then decode to string
            line = line[2:].decode('utf-8')
            if line == 'stop':
                self._client.stop()
                line = None
            else:
                arr = line.split(':')
                self._client.parse_objects(arr[0])
                self._client.parse_objects(arr[1])
                self._client.parse_meta(arr[2])
                self._client.turn()
                line = self.read(1638400)
