class MapObject:
    def __init__(self, arr):
        self.type = int(arr[0])
        self.x = float(arr[1])
        self.y = float(arr[2])
        self.value = int(arr[3])
        self.own = int(arr[4])
        self.size = 0
        self.id = 0
        self.from_id = 0
        self.to_id = 0
        self.number_of_turns = 0
        if self.type == 1:
            self.size = int(arr[5])
        else:
            self.from_id = int(arr[5])
            self.to_id = int(arr[6])
            self.number_of_turns = int(arr[7])
