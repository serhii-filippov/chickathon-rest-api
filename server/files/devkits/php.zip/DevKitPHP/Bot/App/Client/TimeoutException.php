<?php

namespace App\Client;

class TimeoutException extends \Exception
{

}