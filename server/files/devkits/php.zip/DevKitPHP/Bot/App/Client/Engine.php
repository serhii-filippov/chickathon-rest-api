<?php

namespace App\Client;

class Engine
{
    /**
     * @var string $ip
     */
    private $ip;

    /**
     * @var int $port
     */
    private $port;

    /**
     * @var int $port
     */
    private $forkPid;

    /**
     * Socket
     * @var mixed $socket
     */
    private $socket;

    /**
     * @var BotInterface
     */
    private $bot;

    /**
     * @var string
     */
    private $botClass;

    /**
     * @var Client
     */
    private $client;

    /**
     * @var Client
     */
    private $byteLength;

    /**
     * @var resource
     */
    private $shm;


    /**
     * @var string
     */
    private $gotSignal = false;

    /**
     * Client constructor.
     *
     * @param string $ip
     * @param int $port
     * @param string $botClass
     */
    public function __construct(string $ip, int $port, string $botClass)
    {
        $this->port = $port;
        $this->ip = $ip;
        $this->byteLength = 1024 * 100;
        $this->botClass = $botClass;
        $this->shm = shmop_open(0, "n", 0660, $this->byteLength);
    }

    public function run()
    {
        if (!$this->socket) {
            $this->socketConnect();
            $this->fork();
        }
    }

    private function socketConnect()
    {
        echo 'connecting: ' . $this->ip . " p: " . $this->port . PHP_EOL;
        $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        socket_connect($this->socket, $this->ip, $this->port);
        socket_set_block($this->socket);
    }

    private function fork()
    {
        pcntl_async_signals(true);
        $parentPid = getmypid();
        $pid = pcntl_fork();
        if ($pid == -1) {
            exit(1);
        } else {
            if ($pid) {
                $this->forkPid = $pid;
                $this->client = new Client($this);
                $this->bot = new $this->botClass;
                pcntl_signal(SIGALRM, [$this, 'turnHandler']);
                $this->waitSignal();
            } else {
                pcntl_signal(SIGTERM, function () {
//                    socket_shutdown($this->socket, 2);
//                    socket_close($this->socket);
                    exit(0);
                });
                usleep(5);
                $this->socketRead($parentPid);
            }
        }
    }

    private function socketRead($parentPid)
    {
        while ($out = socket_read($this->socket, $this->byteLength)) {
            if ($out) {
                $this->setGameData($out);
                posix_kill($parentPid, SIGALRM);
            }
        }
    }

    private function setGameData($str)
    {
        shmop_write($this->shm, str_pad($str, shmop_size($this->shm), ' ', STR_PAD_RIGHT), 0);
    }

    public function socketWrite(string $message)
    {
        $len = strlen($message);
        $message = chr(0xff & ($len >> 8)) . chr(0xff & $len) . $message;
        socket_write($this->socket, $message, strlen($message));
    }

    public function turnHandler()
    {
        if ($this->gotSignal) {
            echo 'turn timeout';
            throw new TimeoutException;
        } else {
            $this->gotSignal = true;
        }
    }

    private function getGameData()
    {
        $data = shmop_read($this->shm, 0, shmop_size($this->shm));
        return trim($data);
    }

    private function turn()
    {
        $data = $this->getGameData();
        if (substr($data, -4) === 'stop') {
            $this->shutdown();
        }
        $str = mb_strcut($data, 2, null ,'UTF-8');
        $arr = explode(':', $str);
        if ($arr) {
            $this->client->parseData($arr);
            $this->bot->turn($this->client, $this->client->turnNumber);
        }

    }

    private function waitSignal()
    {
        try {
            while (true) {
                if ($this->gotSignal) {
                    $this->turn();
                    $this->gotSignal = false;
                }
                usleep(1);
            }
        } catch (TimeoutException $e) {
            $this->gotSignal = true;
            $this->waitSignal();
        }
    }

    private function shutdown()
    {
        echo 'shutdown';
        posix_kill($this->forkPid, SIGTERM);
        pcntl_waitpid($this->forkPid, $status);
        exit(0);
    }

}