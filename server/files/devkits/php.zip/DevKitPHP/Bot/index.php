<?php
if(empty($botClass)) {
    echo 'Choose bot name';
    exit;
}

if(!class_exists($botClass)) {
    echo 'Bot with name: ' . $botClass . ' not exists';
    exit;
}

$ip = $argv[1] ?? '127.0.0.1';
$port = $argv[2] ?? 15000;

(new \App\Client\Engine($ip, $port, $botClass))->run();
