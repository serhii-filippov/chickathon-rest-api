<?php

require_once 'SequenceBot/vendor/autoload.php';

$botClass = \SequenceBot\SequenceBot::class;

require_once 'index.php';