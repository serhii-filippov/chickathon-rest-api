<?php
namespace SequenceBot;

use App\Client\BotInterface;
use App\Client\Client;

class SequenceBot implements BotInterface
{
    public function turn(Client $client, int $turnNumber)
    {
        $this->debug('notMyPlanets cnt:' . count($client->notMyPlanets));
        if (count($client->notMyPlanets) > 0) {
            $toPlanet = reset($client->notMyPlanets);
            $this->debug('$toPlanet id:' . $toPlanet->id);
            $this->debug('myPlanets cnt:' . count($client->myPlanets));
            foreach ($client->myPlanets as $planet) {
                $this->debug('myPlanets:' .  $planet->id . ' has ships cnt:' . $planet->value);
                if ($planet->value > 1) {
                    $ships = $planet->value === 3 ? 1 : round($planet->value / 2);

                    $this->debug('turnsFromTo: ' . $client->turnsFromTo($planet, $toPlanet));
                    $this->debug('distance: ' . $client->distance($planet, $toPlanet));
                    $this->debug('shipsSpeed: ' . $client->shipsSpeed());
                    $this->debug('SEND from:' .  $planet->id . ' to:' . $toPlanet->id . 'ships:' . $ships);
                    $client->send($planet, $toPlanet, $ships);
                    $planet->value -= $ships;
                }
            }
        }
        $this->debug('endTurn');
        $this->debug('____________________________');
        $client->endTurn();
    }

    private function debug($str)
    {
        echo $str . PHP_EOL;
    }
}