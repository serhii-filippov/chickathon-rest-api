const net = require('net');

/**
 * @class SocketClient
 */
class SocketClient {
  static get STOP() {
    return 'stop';
  }
  /**
   * @param {Number} port
   * @param {String} [host="localhost"]
   */
  constructor(port, host = 'localhost') {
    this._port = port;
    this._host = host;
    this._socket = null;
    this._onDataSubscribers = [];
    this._onStopSubscribers = [];
  }

  /**
   * @private
   */
  _endHandler() {
    console.log('disconnected from server');
    process.exit(0);
  };
  /**
   * @private
   */
  _errorHandler(error) {
    console.error(error);
    process.exit(1);
  };
  /**
   * @private
   */
  _dataHandler(buffer) {
    const payloadString = this._getBufferPayload(buffer);
    if (this._isStopMessage(payloadString)) {
      this._onStopSubscribers.forEach(handler => handler());
      return;
    }
    const { planets, ships, meta } = this._parsePayloadString(payloadString);
    this._onDataSubscribers.forEach(handler => handler({ planets, ships, meta }));
  };

  /**
   * @param {String} payloadString
   * @returns {Boolean}
   * @private
   */
  _isStopMessage(payloadString) {
    return payloadString === SocketClient.STOP;
  }

  /**
   * @private
   * @param {Buffer} buffer
   * @returns {String}
   */
  _getBufferPayload(buffer) {
    return buffer.slice(2).toString();
  }

  /**
   * @private
   * @param {String} string
   * @returns {Object}
   */
  _parsePayloadString(string) {
    return string.split(':')
      .reduce((acc, item) => {
        const [ key, value ] = item.split('#');
        acc[key] = value.split(';');
        return acc;
      }, {});
  }

  /**
   * @public
   */
  connect() {
    this._socket = net.connect(this._port, this._host, () => {
      console.log(`CLIENT CONNECTED TO SOCKET ON PORT ${this._port}`);
    });
    this._socket.on('data', this._dataHandler.bind(this));
    this._socket.on('end', this._endHandler.bind(this));
    this._socket.on('error', this._errorHandler.bind(this));
  }

  /**
   * @public
   * @param {String} payload
   */
  send(payload) {
    try {
      const buf = Buffer.alloc(2);
      buf[0] = (0xff & (payload.length >> 8));
      buf[1] = (0xff & payload.length);
      this._socket.write(buf + payload);
    } catch (error) {
      this._errorHandler(error);
    }
  }

  /**
   * @public
   * @param {Function} handler
   * @return {Function} - remove subscription
   */
  onData(handler) {
    this._onDataSubscribers.push(handler);
    return () => this._onDataSubscribers.filter(item => item !== handler);
  }

  /**
   * @public
   * @param {Function} handler
   * @return {Function} - remove subscription
   */
  onStop(handler) {
    this._onStopSubscribers.push(handler);
    return () => this._onStopSubscribers.filter(item => item !== handler);
  }

  disconnect() {
    process.exit(0);
  }
}

module.exports = SocketClient;