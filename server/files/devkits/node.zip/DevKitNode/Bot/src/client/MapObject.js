/**
 * @class MapObject
 * @param {String} params
 * @property {Number} id
 * @property {Number} x
 * @property {Number} y
 * @property {Number} value
 * @property {Number} own
 * @property {Number} type
 * @property {Number} size
 * @property {Number} fromId
 * @property {Number} toId
 * @property {Number} numberOfTurns
 */
class MapObject {
  static get MY() {
    return 1;
  }
  static get ENEMY() {
    return 2;
  }
  constructor(params) {
    const [type, x, y, value, own, size, fromId, toId, numberOfTurns] = params
      .split(',')
      .map(Number.parseFloat);
    this.type = type;
    this.x = x;
    this.y = y;
    this.value = value;
    this.own = own;


    if (this.type === 1) {
      this.size = size;
      this.fromId = 0;
      this.toId = 0;
      this.numberOfTurns = 0;
    } else {
      this.size = 0;
      this.id = 0;
      this.fromId = fromId;
      this.toId = toId;
      this.numberOfTurns = numberOfTurns;
    }
  }

  isMy() {
    return this.own === MapObject.MY;
  }

  isEnemy() {
    return this.own === MapObject.ENEMY;
  }
}

module.exports = MapObject;