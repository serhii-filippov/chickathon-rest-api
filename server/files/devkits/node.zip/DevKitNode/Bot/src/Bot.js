const fs = require('fs');
const path = require('path');
const MapObject = require('./client/MapObject');

/**
 * @class Bot
 *
 */
class Bot {
  static get END_TURN() {
    return '#endTurn';
  };

  /**
   * @param {SocketClient} client
   * @param {String} [resultFileName]
   */
  constructor(client, resultFileName) {
    this._resultFileName = resultFileName;
    this._client = client;
    this._startTime = Date.now();
    this._shipSpeed = 0;
    this._turnsCount = 0;
    this._myPlanets = [];
    this._enemyPlanets = [];
    this._freePlanets = [];
    this._myShips = [];
    this._enemyShips = [];
    this._virtualCenter = {
      x: 0.25,
      y: 0.5
    };
    this._planetDefenderShipCount = 30;
  }

  /**
   * @private
   */
  _setVirtualCenter() {
    const { maxX, minX, maxY, minY  } = this._getPlanetEdgeCoordinates();
    this._virtualCenter = {
      x: (maxX + minX) / 2,
      y: (maxY + minY) / 2
    };
  }

  _setPlanetDefenderShipCount() {
    const enemyShipValueByPlanet = this._enemyShips.reduce((acc, ship) => {
      acc[ship.toId] = acc[ship.toId] || 0 + ship.value;
      return acc;
    }, {});
    const max = Math.max(...Object.values(enemyShipValueByPlanet));
    this._planetDefenderShipCount = this._enemyPlanets.length + max;
  }

  /**
   * @param {Object} prev
   * @param {Number} prev.value
   * @param {Object} next
   * @param {Number} next.value
   * @return {Number}
   * @private
   */
  _sortByValue(prev, next) {
    return prev.value >= next.value ? 1 : -1;
  };

  /**
   * @param {Object} prev
   * @param {Number} prev.distance
   * @param {Object} next
   * @param {Number} next.distance
   * @return {Number}
   * @private
   */
  _sortByDistance(prev, next) {
    return prev.distance >= next.distance ? 1 : -1;
  };

  _mapPlanets(planet) {
    return {
      planet: planet,
      value: planet.value,
      distance: this._getDistance(this._virtualCenter, planet)
    }
  }

  /**
   * @param {Object} from
   * @param {Number} from.x
   * @param {Number} from.y
   * @param {Object} to
   * @param {Number} to.x
   * @param {Number} to.y
   * @return {Number}
   * @private
   */
  _getDistance(from, to) {
    const x = from.x - to.x;
    const y = from.y - to.y;
    return Math.sqrt(x * x + y * y);
  }

  /**
   * @return {{minY: number, minX: number, maxY: number, maxX: number}}
   * @private
   */
  _getPlanetEdgeCoordinates() {
    const { x, y } = this._myPlanets
      .map(({ x, y }) => ({ x, y }))
      .reduce((acc, { x, y }) => {
        acc.x.push(x);
        acc.y.push(y);
        return acc;
      }, { x: [], y: [] });
    return {
      minX: Math.min(...x),
      maxX: Math.max(...x),
      minY: Math.min(...y),
      maxY: Math.max(...y)
    }
  }

  _mapPlanetsData(planets) {
    this._myPlanets = [];
    this._enemyPlanets = [];
    this._freePlanets = [];
    planets.map((params, index) => {
      const planet = new MapObject(params);
      planet.id = index;
      return planet;
    }).forEach(planet => {
      if (planet.isMy()) {
        this._myPlanets.push(planet);
      } else if (planet.isEnemy()) {
        this._enemyPlanets.push(planet);
      } else {
        this._freePlanets.push(planet);
      }
    });
    this._freePlanets = this._freePlanets.map(this._mapPlanets.bind(this));
    this._enemyPlanets = this._enemyPlanets.map(this._mapPlanets.bind(this));
    this._sortPlanetsByPriority();
  }

  _sortPlanetsByPriority() {
    const primarySort = this._sortByValue;
    const secondarySort = this._sortByDistance;
    this._freePlanets
      .sort(secondarySort)
      .sort(primarySort);
    this._enemyPlanets
      .sort(secondarySort)
      .sort(primarySort);
  }

  _mapShipsData(ships) {
    this._myShips = [];
    this._enemyShips = [];
    ships
      .map(data => new MapObject(data))
      .forEach(ship => {
        ship.isMy()
          ? this._myShips.push(ship)
          : this._enemyShips.push(ship);
      });
  }

  /**
   * @returns {boolean}
   * @private
   */
  _isFreePlanetsExist() {
    return this._freePlanets.length > 0;
  }

  /**
   * @param {MapObject} planet
   * @return {{enemy: Number, my: Number}}
   * @private
   */
  _getAttackingShipCount(planet) {
    const my = this._myShips
      .filter(ship => ship.toId === planet.id)
      .reduce((acc, ship) => {
        acc += ship.value;
        return acc;
      }, 0);
    const enemy = this._enemyShips
      .filter(ship => ship.toId === planet.id)
      .reduce((acc, ship) => {
        acc += ship.value;
        return acc;
      }, 0);
    return { my, enemy };
  }

  /**
   * @param {String[]} planets
   * @param {String[]} ships
   * @param {String[]} meta
   * @private
   */
  _handleData({ planets, ships, meta }) {
    this._mapPlanetsData(planets);
    this._setVirtualCenter();
    this._mapShipsData(ships);
    this._setPlanetDefenderShipCount();
    this._shipSpeed = meta[0];
    this._turnsCount = meta[1];
    this.turn();
  };

  /**
   * @private
   */
  _handleStop() {
    const stats = [
      `START_TIME:${new Date(this._startTime).toISOString()}`,
      `RESULT:${this._myPlanets.length > this._enemyPlanets.length ? 'WIN' : 'LOOSE'}`,
      `GAME_TIME:${Math.floor((Date.now() - this._startTime) / 1000)}s`,
      `TURNS_COUNT:${this._turnsCount}`,
      `PLANETS_COUNT:${this._myPlanets.length + this._enemyPlanets.length}`
    ];
    console.log(stats.join('\n'));
    if (this._resultFileName) {
      const resultFile = path.resolve(process.cwd(), this._resultFileName);
      try {
        fs.statSync(resultFile);
        const data = fs.readFileSync(resultFile);
        fs.writeFileSync(resultFile, data + '\n' +stats.join(','));
      } catch (error) {
        fs.writeFileSync(resultFile, stats.join(','));
      }
    }
    this._client.disconnect();
  }

  /**
   * @param {MapObject} from
   * @param {MapObject} to
   * @param {Number} count
   * @private
   */
  _sentFromTo(from, to, count) {
    this._client.send(`#send:${from.id},${to.id},${count}`);
  }

  /**
   * @returns {{planet: MapObject, distance: Number, value: Number}}
   * @private
   */
  _getMainTarget() {
    const [ target ] = [
      ...this._freePlanets,
      ...this._enemyPlanets
    ];
    return target;
  }

  /**
   * @param {MapObject} planet
   * @returns {Number}
   * @private
   */
  _getTurnShipCountForPlanet(planet) {
    return this._isFreePlanetsExist()
      ? planet.value
      : planet.value > this._planetDefenderShipCount
        ? planet.value - this._planetDefenderShipCount
        : 1;
  }

  /**
   * @param {MapObject} planet
   * @returns {Boolean}
   * @private
   */
  _isPlanetWillSoonCaptured(planet) {
    const attackingPlanetShips = this._getAttackingShipCount(planet);
    return planet.value + attackingPlanetShips.enemy + 2 < attackingPlanetShips.my;
  }

  /**
   * @param {MapObject} planet
   * @param {Object} mainTarget
   * @param {Number} mainTarget.distance
   * @param {MapObject} mainTarget.planet
   * @returns {MapObject|null}
   * @private
   */
  _getPlanetTarget(planet, mainTarget) {
    if (this._isFreePlanetsExist()) {
      const [ planetTarget ] = this._freePlanets
        .map(item => ({
          distance: this._getDistance(planet, item.planet),
          planet: item.planet
        }))
        .filter(({ planet }) => !this._isPlanetWillSoonCaptured(planet))
        .sort(this._sortByDistance);
      if (planetTarget && mainTarget.distance - planetTarget.distance > 0.1 ) {
        return planetTarget.planet
      }
    }

    return mainTarget && mainTarget.planet || null;
  }

  start() {
    this._client.connect();
    this._client.onData(this._handleData.bind(this));
    this._client.onStop(this._handleStop.bind(this));
  }

  turn() {
    const mainTarget = this._getMainTarget();
    if (mainTarget) {
      this._myPlanets.forEach(planet => {
        this._sentFromTo(
          planet,
          this._getPlanetTarget(planet, mainTarget),
          this._getTurnShipCountForPlanet(planet));
      });
    }
    this.turnEnd();
  }

  turnEnd() {
    this._client.send(Bot.END_TURN);
  }
}

module.exports = Bot;