const Bot = require('./src/Bot');
const SocketClient = require('./src/client/SocketClient');

const PORT = process.env.NODE_PORT || 15000;
const RESULTS_FILE = process.env.RESULTS_FILE;

const client = new SocketClient(PORT);
const bot = new Bot(client, RESULTS_FILE);

bot.start();
