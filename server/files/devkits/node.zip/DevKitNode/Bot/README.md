### NODE SOCKET CLIENT

## Environment variables:

`NODE_PORT` - socket connection port (default 15000);

`RESULTS_FILE` - file name for logging run results ("results.txt")

each result will saved to next line, with follow data:
```
START_TIME:2019-01-25T14:11:30.420Z,RESULT:WIN,GAME_TIME:10s,TURNS_COUNT:172,PLANETS_COUNT:32
```

## Run

```
    node main.js
```