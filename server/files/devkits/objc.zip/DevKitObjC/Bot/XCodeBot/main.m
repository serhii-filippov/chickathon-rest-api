//
//  main.m
//  XCodeBot
//
//  Created by Andrew on 12/4/17.
//  Copyright © 2017 CHI. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XCodeBot.h"
#import "Client.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSString *port = @"15000";
        if (argc == 3) {
            port = [NSString stringWithUTF8String:argv[2]];
        }
        
        XCodeBot *bot = [[XCodeBot alloc] init];
        Client *client = [[Client alloc] initWithBot:bot port:port];
        while (client.shouldStop == NO) {
            [NSThread sleepForTimeInterval:1];
        }
    }
    
    return 0;
}
