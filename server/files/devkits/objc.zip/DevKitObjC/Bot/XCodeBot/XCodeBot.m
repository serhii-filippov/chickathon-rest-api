//
//  XCodeBot.m
//  XCodeBot
//
//  Created by Andrew on 12/4/17.
//  Copyright © 2017 CHI. All rights reserved.
//

#import "XCodeBot.h"
#import "Client.h"
#import "MapObject.h"

@implementation XCodeBot

- (instancetype)init {
    self = [super init];
    
    if (self) {
        
    }
    
    return self;
}

- (void)turn:(Client *)client turnNumber:(int)turnNumber {
    // Логику бота писать тут
    if (client.enemyPlanets.count > 0) {
        for (MapObject *planet in client.myPlanets) {
            int shouldSend = arc4random() % 3;
            if (planet.value > 0) {
                int shipsToSend = (arc4random() % planet.value) * shouldSend;
                if (shipsToSend > 0) {
                    int toPlanetId = arc4random() % client.allPlanets.count;
                    if (toPlanetId != planet.id) {
                        MapObject *toPlanet = client.allPlanets[toPlanetId];
                        [client sendFrom:planet to:toPlanet count:shipsToSend];
                    }
                }
            }
        }
    }
    
    [client endTurn];
}

@end
