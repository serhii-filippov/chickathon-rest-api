//
//  XCodeBot.h
//  XCodeBot
//
//  Created by Andrew on 12/4/17.
//  Copyright © 2017 CHI. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BotInterface.h"

@interface XCodeBot : NSObject <BotInterface>

@end
