//
//  MapObject.h
//  XCodeBot
//
//  Created by Andrew on 12/4/17.
//  Copyright © 2017 CHI. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MapObject : NSObject

@property (nonatomic) double x;
@property (nonatomic) double y;
@property (nonatomic) int type;
@property (nonatomic) int size;
@property (nonatomic) int value;
@property (nonatomic) int own;
@property (nonatomic) int numberOfTurns;
@property (nonatomic) int id;
@property (nonatomic) int fromId;
@property (nonatomic) int toId;

- (instancetype)initWithString:(NSString *)string;

@end
