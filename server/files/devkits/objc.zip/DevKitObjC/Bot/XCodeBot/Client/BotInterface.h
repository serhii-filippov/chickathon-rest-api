//
//  BotInterface.h
//  XCodeBot
//
//  Created by Andrew on 12/4/17.
//  Copyright © 2017 CHI. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Client;

@protocol BotInterface <NSObject>
- (void)turn:(Client *)client turnNumber:(int)turnNumber;
@end
