//
//  Client.m
//  XCodeBot
//
//  Created by Andrew on 12/4/17.
//  Copyright © 2017 CHI. All rights reserved.
//

#import "Client.h"
#import "BotInterface.h"
#import "MapObject.h"

#define BUFFER_LEN 102400

@interface Client () <NSStreamDelegate>

@property (nonatomic) NSInteger _port;
//@property (nonatomic) DataInputStream _in;
//@property (nonatomic) DataOutputStream _out;
@property (nonatomic, strong) id<BotInterface> _bot;
@property (nonatomic) double _shipsSpeed;
@property (nonatomic, strong) NSThread *_thread;
@property (nonatomic, strong) NSInputStream *_inputStream;
@property (nonatomic, strong) NSOutputStream *_outputStream;

@end

@implementation Client

- (instancetype)initWithBot:(id<BotInterface>)bot port:(NSString *)port {
    self = [super init];
    
    if (self) {
        self._bot = bot;
        self._port = [port integerValue];
        self.turnNumber = 0;
        self._shipsSpeed = 0.04; // default value
        self.shouldStop = false;
        self._thread = [[NSThread alloc] initWithTarget:self selector:@selector(run) object:nil];
        [self._thread start];
    }
    
    return self;
}

- (void)run {
    BOOL connected = NO;
    
    CFReadStreamRef readStream = NULL;
    CFWriteStreamRef writeStream = NULL;
    while (!connected) {
        connected = YES;
        @try {
            CFStreamCreatePairWithSocketToHost(kCFAllocatorDefault, (CFStringRef)@"localhost", (UInt32)self._port, &readStream, &writeStream);
        } @catch (NSException *exception) {
            connected = NO;
            [NSThread sleepForTimeInterval:500];
        } @finally {}
    }
    
    self._inputStream = (__bridge_transfer NSInputStream *)readStream;
    self._outputStream = (__bridge_transfer NSOutputStream *)writeStream;
    self._inputStream.delegate = self;
    self._outputStream.delegate = self;
    [self._inputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    [self._inputStream open];
    [self._outputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    [self._outputStream open];

    [[NSRunLoop currentRunLoop] run];
}

- (void)stream:(NSStream *)stream handleEvent:(NSStreamEvent)eventCode {
    switch(eventCode) {
        case NSStreamEventHasBytesAvailable: {
            if (stream == self._inputStream) {
                uint8_t *buffer;
                NSUInteger length;
                BOOL freeBuffer = NO;
                // The stream has data. Try to get its internal buffer instead of creating one
                if([self._inputStream getBuffer:&buffer length:&length] == NO) {
                    // The stream couldn't provide its internal buffer. We have to make one ourselves
                    buffer = malloc(BUFFER_LEN * sizeof(uint8_t));
                    freeBuffer = YES;
                    NSInteger result = [self._inputStream read:buffer maxLength:BUFFER_LEN];
                    if(result < 0) {
                        // error copying to buffer
                        break;
                    }
                    length = result;
                    NSData *data = [NSData dataWithBytes:buffer length:length];
                    NSString *string = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
                    if (string.length > 2) {
                        string = [string substringFromIndex:2];
                    }
                    if (string) {
                        if ([string isEqualToString:@"stop"]) {
                            [self stop];
                        } else {
                            NSArray *components = [string componentsSeparatedByString:@":"];
                            if (components.count == 3) {
                                [self parseObjects:components[0]];
                                [self parseObjects:components[1]];
                                [self parseMeta:components[2]];
                                [self turn];
                            } else {
                                [self endTurn];
                            }
                        }
                    }
                }
                // length bytes of data in buffer
                if (freeBuffer) {
                    free(buffer);
                }
            }
        } break;
            
        case NSStreamEventHasSpaceAvailable: {
        } break;
            
        case NSStreamEventEndEncountered: {
            [stream close];
            [stream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        } break;
            
        case NSStreamEventErrorOccurred: {
            
        } break;
            
            
        default:;
    }
}

- (void)parseMeta:(NSString *)string {
    NSArray *arr = [string componentsSeparatedByString:@"#"];
    if (arr.count > 1) {
        NSArray *ps = [arr[1] componentsSeparatedByString:@";"];
        self._shipsSpeed = [ps[0] doubleValue];
        self.turnNumber = [ps[1] intValue];
    }
}

- (void)parseObjects:(NSString *)string {
    NSArray *arr = [string componentsSeparatedByString:@"#"];
    NSMutableArray *list = [NSMutableArray new];
    
    if (arr.count > 1) {
        NSArray *ps = [arr[1] componentsSeparatedByString:@";"];
        for (int i = 0; i < ps.count; i++) {
            NSString *objectString = ps[i];
            MapObject *object = nil;
            if ([objectString isEqualToString:@""] == NO) {
                object = [[MapObject alloc] initWithString:objectString];
            }
            object.id = i;
            if (object) {
                [list addObject:object];
            }
        }
    }
    
    if ([arr[0] isEqualToString:@"planets"]) {
        self.allPlanets = [NSMutableArray new];
        self.myPlanets = [NSMutableArray new];
        self.notMyPlanets = [NSMutableArray new];
        self.enemyPlanets = [NSMutableArray new];
        self.neutralPlanets = [NSMutableArray new];
        for (MapObject *object in list) {
            [self.allPlanets addObject:object];
            switch (object.own) {
                case 0: {
                    [self.neutralPlanets addObject:object];
                    [self.notMyPlanets addObject:object];
                } break;
                    
                case 1: {
                    [self.myPlanets addObject:object];
                } break;
                    
                case 2: {
                    [self.enemyPlanets addObject:object];
                    [self.notMyPlanets addObject:object];
                } break;
            }
        }
    }
    if ([arr[0] isEqualToString:@"ships"]) {
        self.allShips = [NSMutableArray new];
        self.myShips = [NSMutableArray new];
        self.enemyShips = [NSMutableArray new];
        for (MapObject *object in list) {
            [self.allShips addObject:object];
            switch (object.own) {
                case 1: {
                    [self.myShips addObject:object];
                } break;
                    
                case 2: {
                    [self.enemyShips addObject:object];
                } break;
            }
        }
    }
}

- (void)turn {
    [self._bot turn:self turnNumber:self.turnNumber];
}

- (void)stop {
    [self._inputStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    [self._inputStream close];
    [self._outputStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    [self._outputStream close];
    CFReadStreamRef readStream = (__bridge CFReadStreamRef)(self._inputStream);
    CFWriteStreamRef writeStream = (__bridge CFWriteStreamRef)(self._outputStream);
    CFReadStreamClose(readStream);
    CFWriteStreamClose(writeStream);
    self._inputStream = nil;
    self._outputStream = nil;

    CFRunLoopStop(CFRunLoopGetCurrent());
    self.shouldStop = true;
}

- (void)sendString:(NSString *)string {
    if ([self._outputStream hasSpaceAvailable]) {
        NSData *data = [self convertToJavaUTF8:string];
        [self._outputStream write:[data bytes] maxLength:[data length]];
    }
}

- (void)endTurn {
    [self sendString:@"#endTurn"];
}

- (void)sendFrom:(MapObject *)from to:(MapObject *)to count:(int)count {
    NSString *string = [NSString stringWithFormat:@"#send:%d,%d,%d", from.id, to.id, count];
    [self sendString:string];
    from.value -= count;
}

- (NSData*)convertToJavaUTF8:(NSString*)str {
    NSUInteger len = [str lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
    Byte buffer[2];
    buffer[0] = (0xff & (len >> 8));
    buffer[1] = (0xff & len);
    NSMutableData *outData = [NSMutableData dataWithCapacity:2];
    [outData appendBytes:buffer length:2];
    [outData appendData:[str dataUsingEncoding:NSUTF8StringEncoding]];
    return outData;
}

- (double)distanceFrom:(MapObject *)from to:(MapObject *)to {
    double x = to.x - from.x;
    double y = to.y - from.y;
    double distance = sqrt(x*x + y*y);
    return distance;
}

- (int)turnsFrom:(MapObject *)from to:(MapObject *)to {
    double distance = [self distanceFrom:from to:to];
    double turns = distance / self._shipsSpeed;
    int intTurns = (int)turns;
    if (turns > intTurns) {
        intTurns++;
    }
    return intTurns;
}

- (double)shipsSpeed {
    return self._shipsSpeed;
}


@end
