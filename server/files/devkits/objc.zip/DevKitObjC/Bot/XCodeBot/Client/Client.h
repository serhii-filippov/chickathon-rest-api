//
//  Client.h
//  XCodeBot
//
//  Created by Andrew on 12/4/17.
//  Copyright © 2017 CHI. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BotInterface.h"

@class MapObject;

@interface Client : NSObject

@property (nonatomic, strong) NSMutableArray *allPlanets;
@property (nonatomic, strong) NSMutableArray *myPlanets;
@property (nonatomic, strong) NSMutableArray *enemyPlanets;
@property (nonatomic, strong) NSMutableArray *neutralPlanets;
@property (nonatomic, strong) NSMutableArray *notMyPlanets;
@property (nonatomic, strong) NSMutableArray *allShips;
@property (nonatomic, strong) NSMutableArray *myShips;
@property (nonatomic, strong) NSMutableArray *enemyShips;
@property (nonatomic) int turnNumber;
@property (nonatomic) BOOL shouldStop;

- (instancetype)initWithBot:(id<BotInterface>)bot port:(NSString *)port;
- (void)endTurn;
- (void)sendFrom:(MapObject *)from to:(MapObject *)to count:(int)count;
- (double)distanceFrom:(MapObject *)from to:(MapObject *)to;
- (int)turnsFrom:(MapObject *)from to:(MapObject *)to;
- (double)shipsSpeed;

@end
