//
//  MapObject.m
//  XCodeBot
//
//  Created by Andrew on 12/4/17.
//  Copyright © 2017 CHI. All rights reserved.
//

#import "MapObject.h"

@implementation MapObject

- (instancetype)initWithString:(NSString *)string {
    self = [super init];
    
    if (self) {
        NSArray *arr = [string componentsSeparatedByString:@","];
        self.type = [arr[0] intValue];
        self.x = [arr[1] doubleValue];
        self.y = [arr[2] doubleValue];
        self.value = [arr[3] intValue];
        self.own = [arr[4] intValue];
        if (self.type == 1) {
            self.size = [arr[5] intValue];
            self.fromId = 0;
            self.toId = 0;
            self.numberOfTurns = 0;
        } else {
            self.size = 0;
            self.id = 0;
            self.fromId = [arr[5] intValue];
            self.toId = [arr[6] intValue];
            self.numberOfTurns = [arr[7] intValue];
        }
    }
    
    return self;
}

@end
