require_relative 'client/client.rb'
require_relative './ruby_bot.rb'

Client.new(RubyBot, ARGV[0], ARGV[1]).run
