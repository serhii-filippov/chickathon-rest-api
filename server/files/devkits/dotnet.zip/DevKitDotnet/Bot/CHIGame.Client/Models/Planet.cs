﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CHIGame.Client.Models
{
    public class Planet : AbstractMapObject
    {
        public Int32 Size { get; set; }
    }
}
